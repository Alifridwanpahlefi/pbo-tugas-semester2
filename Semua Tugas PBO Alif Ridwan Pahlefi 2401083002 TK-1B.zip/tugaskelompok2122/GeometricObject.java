package tugaskelompok2122;

public interface GeometricObject {
    double getArea();
    double getPerimeter();
}
