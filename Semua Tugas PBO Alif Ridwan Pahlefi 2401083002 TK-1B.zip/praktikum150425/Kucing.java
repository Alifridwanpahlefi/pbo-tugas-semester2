/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum150425;

/**
 *
 * @author Lif Rdwn
 */
public class Kucing extends Hewan{
    public Kucing(String nama){
        super(nama);
    }
    
    public void Suara(){
        System.out.println(nama+"bersuara : mengeong!!!");
    }
    
}
