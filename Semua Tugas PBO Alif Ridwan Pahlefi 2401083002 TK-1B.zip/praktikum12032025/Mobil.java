/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum12032025;

/**
 *
 * @author Lif Rdwn
 */
public class Mobil {
    ///property dari class mobil
    String warna;
    String plat;
    int tahun;
    String merk;
    
    String SuaraMobil(){
        return "Bruuum";
    }
    public void MobilAktif(){
        System.out.println("3...2...1");
        System.out.println("Ready...GO!!!");
    }
}