/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UTSalifridwanpahlefi2401083002;

/**
 *
 * @author Lif Rdwn
 */

public class SepedaListrik extends Sepeda {
    private int kecepatanMaks;
    private int jarakTempuh;

    public void setKecepatanMaks(int kecepatanMaks) {
        this.kecepatanMaks = kecepatanMaks;
    }

    public int getKecepatanMaks() {
        return kecepatanMaks;
    }

    public void setJarakTempuh(int jarakTempuh) {
        this.jarakTempuh = jarakTempuh;
    }

    public int getJarakTempuh() {
        return jarakTempuh;
    }
}

